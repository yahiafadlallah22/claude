<?php
if (!defined('ABSPATH')) { exit; }
$post_id = get_the_ID();
$primary = Flavor_Travel_Hub::get_primary_color();
$secondary = Flavor_Travel_Hub::get_secondary_color();
$price = get_post_meta($post_id, '_fth_price', true);
$original_price = get_post_meta($post_id, '_fth_original_price', true);
$currency = get_post_meta($post_id, '_fth_currency', true) ?: 'USD';
$rating = get_post_meta($post_id, '_fth_rating', true);
$review_count = get_post_meta($post_id, '_fth_review_count', true);
$address = get_post_meta($post_id, '_fth_address', true);
$amenities = get_post_meta($post_id, '_fth_amenities', true);
$affiliate_link = get_post_meta($post_id, '_fth_affiliate_link', true);
$cities = wp_get_post_terms($post_id, 'travel_city');
$countries = wp_get_post_terms($post_id, 'travel_country');
$city_name = !empty($cities) ? $cities[0]->name : '';
$country_name = !empty($countries) ? $countries[0]->name : '';
$symbol_map = array('USD'=>'$','AED'=>'AED ','EUR'=>'€','GBP'=>'£','SAR'=>'SAR ','QAR'=>'QAR ');
$symbol = isset($symbol_map[$currency]) ? $symbol_map[$currency] : $currency . ' ';
$main_image = has_post_thumbnail($post_id) ? get_the_post_thumbnail_url($post_id, 'large') : get_post_meta($post_id, '_fth_external_image', true);
$gallery_images = array();
$gallery_ids = array_filter(array_map('intval', explode(',', (string) get_post_meta($post_id, '_fth_gallery', true))));
foreach ($gallery_ids as $gid) { $url = wp_get_attachment_image_url($gid, 'large'); if ($url) $gallery_images[] = $url; }
$gallery_external = array_filter(array_map('trim', explode(',', (string) get_post_meta($post_id, '_fth_external_gallery', true))));
foreach ($gallery_external as $img) { if ($img && !in_array($img, $gallery_images, true) && $img !== $main_image) $gallery_images[] = $img; }
if ($main_image) array_unshift($gallery_images, $main_image);
$gallery_images = array_values(array_unique(array_filter($gallery_images)));
$amenity_items = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) $amenities)));
$related = FTH_Search::search_hotels(array('city'=>!empty($cities)?$cities[0]->slug:'','per_page'=>4,'paged'=>1));
get_header();
?>
<style>
html,body,#main_wrapper,.master_header,.master_wrapper,.content_wrapper,.container,.site-content{overflow:visible!important;height:auto!important;max-height:none!important;position:static!important}
body.single-travel_hotel .widget-area,body.single-travel_hotel .sidebar,body.single-travel_hotel .right_sidebar,body.single-travel_hotel .page_header,body.single-travel_hotel .title_container,body.single-travel_hotel .wpestate_header_image,body.single-travel_hotel .property_breadcrumbs{display:none!important}
.fth-wrap,.fth-wrap *{box-sizing:border-box}.fth-wrap{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;color:#0f172a;background:#fff;position:relative;z-index:5}.fth-wrap a{text-decoration:none}.fth-wrap img{max-width:100%;height:auto;display:block}.bc{background:#f8fafc;border-top:1px solid #edf2f7;border-bottom:1px solid #edf2f7}.bc-in{max-width:1240px;margin:0 auto;padding:12px 20px;font-size:13px;color:#64748b}.bc a{color:#475569!important}.main{max-width:1240px;margin:0 auto;padding:28px 20px 0}.grid{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:28px}.heroimg{position:relative;border-radius:24px;overflow:hidden;background:#e2e8f0;aspect-ratio:16/9;max-height:560px;box-shadow:0 24px 54px rgba(15,23,42,.12)}.heroimg img{width:100%;height:100%;object-fit:cover}.thumbs{display:flex;gap:10px;overflow:auto;padding:12px 0 2px}.thumbs img{width:100px;height:72px;object-fit:cover;border-radius:12px;border:2px solid transparent;cursor:pointer}.badge{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:8px 14px;border-radius:999px;font-size:12px;font-weight:800;color:#fff;background:<?php echo esc_attr($secondary); ?>}.card,.content,.cta{background:#fff;border:1px solid #e5e7eb;border-radius:24px;box-shadow:0 14px 34px rgba(15,23,42,.06)}.card,.content,.cta{padding:24px}.title{margin:14px 0 10px;font-size:38px;line-height:1.08;text-align:left}.meta{display:flex;flex-wrap:wrap;gap:12px;margin:0 0 18px;padding:0;list-style:none;justify-content:center}.meta li{display:flex;align-items:center;gap:8px;padding:10px 14px;border-radius:999px;background:#f8fafc;color:#334155;font-weight:600}.content{margin-top:20px}.section-title{margin:0 0 14px;font-size:22px;display:flex;align-items:center;gap:10px}.section-title span{display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:10px;background:rgba(41,137,192,.11);color:<?php echo esc_attr($primary); ?>}.copy{color:#475569;line-height:1.8;font-size:15px}.amenities{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px 16px}.price-old{text-decoration:line-through;color:#94a3b8;font-size:14px}.price-new{font-size:38px;font-weight:900;color:<?php echo esc_attr($primary); ?>}.small{color:#64748b;font-size:14px;line-height:1.6}.book{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:15px 18px;border-radius:14px;background:<?php echo esc_attr($primary); ?>;color:#fff!important;font-weight:800;font-size:16px;margin-top:16px}.highlights{display:grid;gap:10px;margin-top:18px}.highlights div{display:flex;gap:10px;align-items:flex-start;color:#334155;font-size:14px}.related-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:18px}@media(max-width:1100px){.grid{grid-template-columns:1fr}.cta{position:static}.related-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:720px){.title{font-size:28px}.amenities,.related-grid{grid-template-columns:1fr}.thumbs img{width:84px;height:60px}}
</style>
<div class="fth-wrap">
  <div class="bc"><div class="bc-in"><a href="<?php echo esc_url(FTH_Templates::get_hub_url('hotels')); ?>">Hotels</a><?php if($city_name): ?> / <span><?php echo esc_html($city_name); ?></span><?php endif; ?> / <span><?php the_title(); ?></span></div></div>
  <div class="main">
    <div class="grid">
      <div>
        <div class="card" style="text-align:center;"><span class="badge">Hotel stay</span><h1 class="title"><?php the_title(); ?></h1><ul class="meta"><?php if($city_name || $country_name): ?><li>📍 <?php echo esc_html(trim($city_name . ($country_name ? ', ' . $country_name : ''))); ?></li><?php endif; ?><?php if($rating): ?><li>⭐ <?php echo esc_html(number_format((float)$rating,1)); ?><?php if($review_count): ?> · <?php echo esc_html(number_format((int)$review_count)); ?> reviews<?php endif; ?></li><?php endif; ?></ul><div class="heroimg"><?php if($gallery_images): ?><img id="fthMainHotelImg" src="<?php echo esc_url($gallery_images[0]); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"><?php endif; ?></div><?php if(count($gallery_images)>1): ?><div class="thumbs"><?php foreach(array_slice($gallery_images,1,6) as $img): ?><img src="<?php echo esc_url($img); ?>" alt="" onclick="document.getElementById('fthMainHotelImg').src=this.src;"><?php endforeach; ?></div><?php endif; ?></div>
        <div class="content"><h2 class="section-title"><span>ℹ</span>Overview</h2><div class="copy"><?php the_content(); ?></div><?php if($address): ?><p style="margin-top:16px;"><strong>Address:</strong> <?php echo esc_html($address); ?></p><?php endif; ?></div>
        <?php if($amenity_items): ?><div class="content"><h2 class="section-title"><span>✓</span>Popular facilities</h2><div class="amenities"><?php foreach(array_slice($amenity_items,0,16) as $item): ?><div>✓ <?php echo esc_html($item); ?></div><?php endforeach; ?></div></div><?php endif; ?>
      </div>
      <aside class="cta">
        <div class="small">Current room rate</div>
        <?php if($original_price && (float)$original_price > (float)$price): ?><div class="price-old"><?php echo esc_html($symbol . number_format((float)$original_price,2)); ?></div><?php endif; ?>
        <?php if($price): ?><div class="price-new"><?php echo esc_html($symbol . number_format((float)$price,2)); ?></div><?php else: ?><div class="price-new" style="font-size:28px;">Check current rate</div><?php endif; ?>
        <p class="small">Check the latest room details, amenities and booking options.</p>
        <a class="book" href="<?php echo esc_url($affiliate_link ?: '#'); ?>" target="_blank" rel="noopener noreferrer">Activate Discount</a>
        <div class="highlights">
          <div><span>🏨</span><span>Room details, location and facilities in one clean layout.</span></div>
          <div><span>📍</span><span>Useful location information to compare hotels faster.</span></div>
          <div><span>✅</span><span>Secure your dates in a few clicks.</span></div>
        </div>
      </aside>
    </div>

    <?php if($related->have_posts()): ?><div class="content"><h2 class="section-title"><span>✨</span>More stays nearby</h2><div class="related-grid"><?php while($related->have_posts()): $related->the_post(); if(get_the_ID() == $post_id) continue; echo FTH_Templates::get_hotel_card(get_the_ID()); endwhile; wp_reset_postdata(); ?></div></div><?php endif; ?>
    <?php echo FTH_Templates::render_seo_footer('hotels'); ?>
  </div>
</div>
<?php get_footer(); ?>
