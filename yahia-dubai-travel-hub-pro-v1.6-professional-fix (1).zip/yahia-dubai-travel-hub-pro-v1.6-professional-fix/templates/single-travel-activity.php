<?php
if (!defined('ABSPATH')) { exit; }
$post_id = get_the_ID();
$primary = Flavor_Travel_Hub::get_primary_color();
$secondary = Flavor_Travel_Hub::get_secondary_color();
$price = get_post_meta($post_id, '_fth_price', true);
$original_price = get_post_meta($post_id, '_fth_original_price', true);
$currency = get_post_meta($post_id, '_fth_currency', true) ?: 'USD';
$rating = get_post_meta($post_id, '_fth_rating', true);
$review_count = get_post_meta($post_id, '_fth_review_count', true);
$duration = get_post_meta($post_id, '_fth_duration', true);
$meeting_point = get_post_meta($post_id, '_fth_meeting_point', true);
$inclusions = get_post_meta($post_id, '_fth_inclusions', true);
$exclusions = get_post_meta($post_id, '_fth_exclusions', true);
$itinerary = get_post_meta($post_id, '_fth_itinerary', true);
$highlights = get_post_meta($post_id, '_fth_highlights', true);
$promo = get_post_meta($post_id, '_fth_promo', true);
$affiliate_link = get_post_meta($post_id, '_fth_affiliate_link', true);
$cities = wp_get_post_terms($post_id, 'travel_city');
$countries = wp_get_post_terms($post_id, 'travel_country');
$city_name = !empty($cities) ? $cities[0]->name : '';
$country_name = !empty($countries) ? $countries[0]->name : '';
$symbol_map = array('USD'=>'$','AED'=>'AED ','EUR'=>'€','GBP'=>'£','SAR'=>'SAR ','QAR'=>'QAR ');
$symbol = isset($symbol_map[$currency]) ? $symbol_map[$currency] : $currency . ' ';
$main_image = has_post_thumbnail($post_id) ? get_the_post_thumbnail_url($post_id, 'large') : get_post_meta($post_id, '_fth_external_image', true);
$gallery_images = array();
$gallery_ids = array_filter(array_map('intval', explode(',', (string) get_post_meta($post_id, '_fth_gallery', true))));
foreach ($gallery_ids as $gid) { $url = wp_get_attachment_image_url($gid, 'large'); if ($url) $gallery_images[] = $url; }
$gallery_external = array_filter(array_map('trim', explode(',', (string) get_post_meta($post_id, '_fth_external_gallery', true))));
foreach ($gallery_external as $img) { if ($img && !in_array($img, $gallery_images, true) && $img !== $main_image) $gallery_images[] = $img; }
if ($main_image) array_unshift($gallery_images, $main_image);
$gallery_images = array_values(array_unique(array_filter($gallery_images)));
$related = FTH_Search::search_activities(array('city'=>!empty($cities)?$cities[0]->slug:'','per_page'=>4,'paged'=>1));
get_header();
?>
<style>
html,body,#main_wrapper,.master_header,.master_wrapper,.content_wrapper,.container,.site-content{overflow:visible!important;height:auto!important;max-height:none!important;position:static!important}
body.single-travel_activity .widget-area,body.single-travel_activity .sidebar,body.single-travel_activity .right_sidebar,body.single-travel_activity .page_header,body.single-travel_activity .title_container,body.single-travel_activity .wpestate_header_image,body.single-travel_activity .property_breadcrumbs{display:none!important}
.fth-wrap,.fth-wrap *{box-sizing:border-box}.fth-wrap{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;color:#0f172a;background:#fff;position:relative;z-index:5}.fth-wrap a{text-decoration:none}.fth-wrap img{max-width:100%;height:auto;display:block}.bc{background:#f8fafc;border-top:1px solid #edf2f7;border-bottom:1px solid #edf2f7}.bc-in{max-width:1240px;margin:0 auto;padding:12px 20px;font-size:13px;color:#64748b}.bc a{color:#475569!important}.main{max-width:1240px;margin:0 auto;padding:28px 20px 0}.grid{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:28px}.heroimg{position:relative;border-radius:24px;overflow:hidden;background:#e2e8f0;aspect-ratio:16/9;max-height:560px;box-shadow:0 24px 54px rgba(15,23,42,.12)}.heroimg img{width:100%;height:100%;object-fit:cover}.badges{position:absolute;top:18px;left:18px;display:flex;gap:10px;flex-wrap:wrap}.badge{display:inline-flex;align-items:center;gap:8px;padding:8px 14px;border-radius:999px;font-size:12px;font-weight:800;color:#fff}.badge.primary{background:<?php echo esc_attr($primary); ?>}.badge.secondary{background:<?php echo esc_attr($secondary); ?>}.thumbs{display:flex;gap:10px;overflow:auto;padding:12px 0 2px}.thumbs button{border:0;background:none;padding:0;cursor:pointer}.thumbs img{width:100px;height:72px;object-fit:cover;border-radius:12px;border:2px solid transparent}.card,.content,.cta{background:#fff;border:1px solid #e5e7eb;border-radius:24px;padding:24px;box-shadow:0 14px 34px rgba(15,23,42,.06)}.title{margin:0 0 14px;font-size:38px;line-height:1.08;text-align:center}.meta{display:flex;flex-wrap:wrap;gap:12px;margin:0 0 18px;padding:0;list-style:none;justify-content:center}.meta li{display:flex;align-items:center;gap:8px;padding:10px 14px;border-radius:999px;background:#f8fafc;color:#334155;font-weight:600}.promo{display:inline-flex;align-items:center;justify-content:center;gap:10px;text-align:center;background:linear-gradient(135deg,<?php echo esc_attr($primary); ?>,<?php echo esc_attr($secondary); ?>);color:#fff;border-radius:18px;padding:15px 18px;font-weight:900;margin:0 0 20px}.content{margin-top:20px}.section-title{margin:0 0 14px;font-size:22px;display:flex;align-items:center;gap:10px}.section-title span{display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:10px;background:rgba(41,137,192,.11);color:<?php echo esc_attr($primary); ?>}.copy{color:#475569;line-height:1.8;font-size:15px}.copy img{max-width:100%!important;height:auto!important;border-radius:16px}.list{display:grid;gap:12px;margin:0;padding:0;list-style:none}.list li{display:flex;gap:10px;align-items:flex-start;padding:12px 0;border-bottom:1px solid #eef2f7;color:#334155}.list li:last-child{border-bottom:none}.check{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:999px;background:rgba(41,137,192,.12);color:<?php echo esc_attr($primary); ?>;font-weight:900;flex:0 0 auto}.cta{position:sticky;top:110px}.price-old{text-decoration:line-through;color:#94a3b8;font-size:14px}.price-new{font-size:38px;font-weight:900;color:<?php echo esc_attr($primary); ?>}.small{color:#64748b;font-size:14px;line-height:1.6}.book{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:15px 18px;border-radius:14px;background:<?php echo esc_attr($primary); ?>;color:#fff!important;font-weight:800;font-size:16px;margin-top:16px}.highlights{display:grid;gap:10px;margin-top:18px}.highlights div{display:flex;gap:10px;align-items:flex-start;color:#334155;font-size:14px}.related{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:18px}@media(max-width:1100px){.grid{grid-template-columns:1fr}.cta{position:static}.related{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:720px){.title{font-size:28px}.related{grid-template-columns:1fr}.thumbs img{width:84px;height:60px}}
</style>
<div class="fth-wrap">
  <div class="bc"><div class="bc-in"><a href="<?php echo esc_url(FTH_Templates::get_hub_url('things-to-do')); ?>">Things to do</a><?php if($city_name): ?> / <span><?php echo esc_html($city_name); ?></span><?php endif; ?> / <span><?php the_title(); ?></span></div></div>
  <div class="main">
    <div class="grid">
      <div>
        <div class="card" style="text-align:center;">
          <?php if($promo): ?><div class="promo"><?php echo esc_html($promo); ?></div><?php endif; ?>
          <h1 class="title"><?php the_title(); ?></h1>
          <ul class="meta"><?php if($city_name || $country_name): ?><li>📍 <?php echo esc_html(trim($city_name . ($country_name ? ', ' . $country_name : ''))); ?></li><?php endif; ?><?php if($duration): ?><li>⏱ <?php echo esc_html($duration); ?></li><?php endif; ?><?php if($rating): ?><li>⭐ <?php echo esc_html(number_format((float)$rating,1)); ?><?php if($review_count): ?> · <?php echo esc_html(number_format((int)$review_count)); ?> reviews<?php endif; ?></li><?php endif; ?></ul>
          <div class="heroimg"><?php if($gallery_images): ?><img id="fthMainImg" src="<?php echo esc_url($gallery_images[0]); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"><?php endif; ?><div class="badges"><span class="badge primary">Instant confirmation</span><span class="badge secondary">Popular experience</span></div></div>
          <?php if(count($gallery_images)>1): ?><div class="thumbs"><?php foreach(array_slice($gallery_images,1,6) as $img): ?><button type="button" onclick="document.getElementById('fthMainImg').src='<?php echo esc_js($img); ?>'"><img src="<?php echo esc_url($img); ?>" alt=""></button><?php endforeach; ?></div><?php endif; ?>
        </div>

        <div class="content"><h2 class="section-title"><span>ℹ</span>Overview</h2><div class="copy"><?php the_content(); ?></div><?php if($meeting_point): ?><p style="margin-top:16px;"><strong>Meeting point:</strong> <?php echo esc_html($meeting_point); ?></p><?php endif; ?></div>
        <?php if($highlights): ?><div class="content"><h2 class="section-title"><span>★</span>Highlights</h2><ul class="list"><?php foreach(array_filter(array_map('trim', explode("\n", $highlights))) as $line): ?><li><span class="check">✓</span><span><?php echo esc_html($line); ?></span></li><?php endforeach; ?></ul></div><?php endif; ?>
        <?php if($itinerary): ?><div class="content"><h2 class="section-title"><span>🗺</span>Itinerary</h2><ul class="list"><?php foreach(array_filter(array_map('trim', explode("\n", $itinerary))) as $line): ?><li><span class="check">•</span><span><?php echo esc_html($line); ?></span></li><?php endforeach; ?></ul></div><?php endif; ?>
        <?php if($inclusions): ?><div class="content"><h2 class="section-title"><span>✓</span>What's included</h2><ul class="list"><?php foreach(array_filter(array_map('trim', explode("\n", $inclusions))) as $line): ?><li><span class="check">✓</span><span><?php echo esc_html($line); ?></span></li><?php endforeach; ?></ul></div><?php endif; ?>
        <?php if($exclusions): ?><div class="content"><h2 class="section-title"><span>✕</span>What's not included</h2><ul class="list"><?php foreach(array_filter(array_map('trim', explode("\n", $exclusions))) as $line): ?><li><span class="check">✕</span><span><?php echo esc_html($line); ?></span></li><?php endforeach; ?></ul></div><?php endif; ?>
      </div>

      <aside class="cta">
        <div class="small">Current offer</div>
        <?php if($original_price && (float)$original_price > (float)$price): ?><div class="price-old"><?php echo esc_html($symbol . number_format((float)$original_price,2)); ?></div><?php endif; ?>
        <?php if($price): ?><div class="price-new"><?php echo esc_html($symbol . number_format((float)$price,2)); ?></div><?php else: ?><div class="price-new" style="font-size:28px;">Check current price</div><?php endif; ?>
        <p class="small">View the latest ticket details, availability and booking options.</p>
        <a class="book" href="<?php echo esc_url($affiliate_link ?: '#'); ?>" target="_blank" rel="noopener noreferrer">Activate Discount</a>
        <div class="highlights">
          <div><span>🎟️</span><span>Tickets, timings and key information in one clean layout.</span></div>
          <div><span>📍</span><span>Location details and useful highlights before you book.</span></div>
          <div><span>✅</span><span>Secure your dates in a few clicks.</span></div>
        </div>
      </aside>
    </div>

    <?php if($related->have_posts()): ?><div class="content"><h2 class="section-title"><span>✨</span>More experiences nearby</h2><div class="related"><?php while($related->have_posts()): $related->the_post(); if(get_the_ID() == $post_id) continue; echo FTH_Templates::get_activity_card(get_the_ID()); endwhile; wp_reset_postdata(); ?></div></div><?php endif; ?>
    <?php echo FTH_Templates::render_seo_footer('activities'); ?>
  </div>
</div>
<?php get_footer(); ?>
