<?php
if (!defined('ABSPATH')) { exit; }
$term = get_queried_object();
if (!$term || is_wp_error($term)) { get_header(); echo '<div class="wrap"><p>Country not found.</p></div>'; get_footer(); return; }
$primary = Flavor_Travel_Hub::get_primary_color();
$flag = FTH_Templates::get_country_flag($term);
$cities = get_terms(array('taxonomy'=>'travel_city','hide_empty'=>false,'meta_query'=>array(array('key'=>'fth_parent_country','value'=>$term->term_id)),'number'=>48,'orderby'=>'name','order'=>'ASC'));
$search_query = isset($_GET['fth_search']) ? sanitize_text_field(wp_unslash($_GET['fth_search'])) : '';
get_header();
?>
<style>
html,body,#main_wrapper,.master_header,.master_wrapper,.content_wrapper,.container,.site-content{overflow:visible!important;height:auto!important;max-height:none!important;position:static!important}
body.tax-travel_country .widget-area,body.tax-travel_country .sidebar,body.tax-travel_country .right_sidebar,body.tax-travel_country .page_header,body.tax-travel_country .title_container,body.tax-travel_country .wpestate_header_image,body.tax-travel_country .property_breadcrumbs{display:none!important}
.shell,.shell *{box-sizing:border-box}.shell{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;background:#fff;color:#0f172a;position:relative;z-index:5}.wrap{max-width:1240px;margin:0 auto;padding:0 20px}.hero{padding:70px 0 44px;background:linear-gradient(180deg,#0f172a 0%,#1e293b 100%)}.hero .flag{font-size:64px;text-align:center}.hero h1{margin:12px 0 10px;font-size:54px;line-height:1.05;color:#fff;text-align:center}.hero p{margin:0 auto 24px;max-width:760px;color:rgba(255,255,255,.92);text-align:center;font-size:18px;line-height:1.6}.search{max-width:760px;margin:0 auto;background:#fff;border-radius:22px;padding:14px;display:grid;grid-template-columns:1fr 170px;gap:12px}.search input{height:58px;padding:0 16px;border:1px solid #dbe3ec;border-radius:14px}.search button{height:58px;border:0;border-radius:14px;background:<?php echo esc_attr($primary); ?>;color:#fff;font-weight:800}.section{padding:46px 0}.head{text-align:center;margin-bottom:22px}.head h2{margin:0 0 8px;font-size:34px;text-align:center}.head p{margin:0 auto;max-width:760px;color:#64748b;text-align:center}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px}.city-box{display:flex;align-items:center;justify-content:center;padding:18px;background:#fff;border:1px solid #e5e7eb;border-radius:18px;font-weight:800;color:#0f172a;box-shadow:0 12px 30px rgba(15,23,42,.05)}@media(max-width:1100px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:720px){.hero h1{font-size:36px}.search,.grid{grid-template-columns:1fr}}
</style>
<div class="shell">
  <section class="hero"><div class="wrap"><div class="flag"><?php echo esc_html($flag); ?></div><h1><?php echo esc_html($term->name); ?></h1><p>Explore cities, activities, tours and hotel stays across <?php echo esc_html($term->name); ?>.</p><form class="search" method="get" action="<?php echo esc_url(FTH_Templates::get_hub_url('things-to-do')); ?>"><input type="hidden" name="fth_mode" value="activities"><input type="hidden" name="fth_country" value="<?php echo esc_attr($term->slug); ?>"><input type="text" name="fth_search" placeholder="Search in <?php echo esc_attr($term->name); ?>" value="<?php echo esc_attr($search_query); ?>"><button type="submit">Search</button></form></div></section>
  <section class="section"><div class="wrap"><div class="head"><h2>Cities in <?php echo esc_html($term->name); ?></h2><p>Open a city to explore attractions and hotels.</p></div><div class="grid"><?php if(!empty($cities) && !is_wp_error($cities)): foreach($cities as $city): ?><a class="city-box" href="<?php echo esc_url(get_term_link($city)); ?>"><?php echo esc_html($city->name); ?></a><?php endforeach; endif; ?></div></div></section>
  <?php echo FTH_Templates::render_seo_footer('activities'); ?>
</div>
<?php get_footer(); ?>
